import java.lang.Math;
import java.util.Scanner;

public class MyProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // pyramid and sphere instances
        Pyramid p1 = new Pyramid(12, 11, 10);
        Sphere s1 = new Sphere(12);

        System.out.println("This will calculate surface area and volume for the shape that you will decide.");
        System.out.println("b for box, p for pyramid, and s for sphere.");

        String shapeString = scanner.nextLine();

        if (shapeString.equals("b")) {
            System.out.println("You chose box");
            System.out.println("Enter length:");
            String length = scanner.nextLine();
            System.out.println("Enter width:");
            String width = scanner.nextLine();
            System.out.println("Enter height:");
            String height = scanner.nextLine();

            // Create the Box
            Box b1 = new Box(Integer.parseInt(length), Integer.parseInt(width), Integer.parseInt(height));

            System.out.println("Your volume is " + b1.calcVol());
            System.out.println("Your surface area is " + b1.calcSurfArea());

        } else if (shapeString.equals("p")) {
            System.out.println("You chose pyramid");
            System.out.println("Enter length:");
            String length = scanner.nextLine();
            System.out.println("Enter width:");
            String width = scanner.nextLine();
            System.out.println("Enter height:");
            String height = scanner.nextLine();

            // Create the Pyramid and calculate the volume and surface area
            Pyramid p2 = new Pyramid(Double.parseDouble(length), Double.parseDouble(width), Double.parseDouble(height));
            System.out.println("Pyramid volume: " + p2.calcVol());
            System.out.println("Pyramid surface area: " + p2.calcSurfArea());

        } else if (shapeString.equals("s")) {
            System.out.println("You chose sphere");
            System.out.println("Enter radius:");
            String radius = scanner.nextLine();

            // Create the Sphere and calculate the volume and surface area
            Sphere s2 = new Sphere(Double.parseDouble(radius));
            System.out.println("Sphere volume: " + s2.calcVol());
            System.out.println("Sphere surface area: " + s2.calcSurfArea());

        } else {
            System.out.println("Invalid choice. Please choose 'b', 'p', or 's'.");
        }

        scanner.close();
    }
}